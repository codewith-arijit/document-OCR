from django.apps import AppConfig


class PcardConfig(AppConfig):
    name = 'pcard'
